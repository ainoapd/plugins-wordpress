
function ggResetUser(userId) {
    if (confirm("¿Estás seguro de que quieres reiniciar el gasto de este usuario?")) {
        const url = new URL(window.location.href);
        url.searchParams.set('reset_user', userId);
        window.location.href = url.toString();
    }
}

function ggResetAll() {
    if (confirm("¿Estás seguro de que quieres reiniciar el gasto de todos los usuarios?")) {
        const url = new URL(window.location.href);
        url.searchParams.set('reset_all', 1);
        window.location.href = url.toString();
    }
}