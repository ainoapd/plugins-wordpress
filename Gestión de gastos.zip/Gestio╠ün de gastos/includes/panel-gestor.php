<?php
add_shortcode('panel_gestor', function() {
    if (!current_user_can('manage_options')) return '<p>No tienes permisos para acceder a este panel.</p>';

    $users = get_users();
    ob_start(); ?>
    <div class="gg-panel">
        <button onclick="ggResetAll()">Reiniciar gasto de todos</button>
        <div class="gg-grid">
        <?php foreach ($users as $user):
            $uid = $user->ID;
            $limite = (float) get_user_meta($uid, 'limite_mensual', true);
            $gasto = (float) get_user_meta($uid, 'gasto_mensual', true);
            $saldo = $limite - $gasto;
        ?>
            <div class="gg-card">
                <h4><?php echo esc_html($user->display_name); ?></h4>
                <p><strong>Límite:</strong></p>
				<form method="get" class="gg-update-form">
   				<input type="hidden" name="user_id" value="<?php echo $uid; ?>">
    			<input type="number" name="update_limit" value="<?php echo $limite; ?>" step="0.01">
    			<button type="submit">Actualizar</button>
				</form>

                <p><strong>Gasto:</strong> <?php echo number_format($gasto, 2); ?> €</p>
                <p><strong>Saldo:</strong> <?php echo number_format($saldo, 2); ?> €</p>
                <button onclick="ggResetUser(<?php echo $uid; ?>)">Poner gasto a 0</button>
            </div>
        <?php endforeach; ?>
        </div>
    </div>
    <?php return ob_get_clean();
});
?>
