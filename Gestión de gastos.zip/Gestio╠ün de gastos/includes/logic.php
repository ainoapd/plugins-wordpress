<?php
// 1. ACTUALIZAR GASTO AL ENVIAR FORMULARIO
add_action('gform_after_submission_1', function($entry) {
    $user_id = (int) rgar($entry, 'created_by');
    $importe = (float) rgar($entry, '8'); // ID del campo de importe

    if ($user_id > 0 && $importe > 0) {
        $gasto_actual = (float) get_user_meta($user_id, 'gasto_mensual', true);
        $nuevo_gasto = $gasto_actual + $importe;
        update_user_meta($user_id, 'gasto_mensual', $nuevo_gasto);
    }
}, 10, 2);

// 2. RESET AUTOMÁTICO EL DÍA 28
add_action('init', function() {
    $hoy = date('Y-m-d');
    $dia = date('d');
    $ultimo_reset = get_option('gg_ultimo_reset');

    if ($dia == '28' && $ultimo_reset !== $hoy) {
        foreach (get_users() as $user) {
            update_user_meta($user->ID, 'gasto_mensual', 0);
        }
        update_option('gg_ultimo_reset', $hoy);
    }
});

// 3. RESET INDIVIDUAL DESDE BOTÓN (GET)
add_action('init', function() {
    if (isset($_GET['reset_user']) && current_user_can('manage_options')) {
        $user_id = (int) $_GET['reset_user'];
        update_user_meta($user_id, 'gasto_mensual', 0);
        wp_redirect(remove_query_arg('reset_user')); exit;
    }
});

// 4. RESET GLOBAL DESDE BOTÓN (GET)
add_action('init', function() {
    if (isset($_GET['reset_all']) && current_user_can('manage_options')) {
        foreach (get_users() as $user) {
            update_user_meta($user->ID, 'gasto_mensual', 0);
        }
        wp_redirect(remove_query_arg('reset_all')); exit;
    }
});

// 5. ACTUALIZAR LÍMITE DESDE PANEL (GET)
add_action('init', function() {
    if (isset($_GET['update_limit'], $_GET['user_id']) && current_user_can('manage_options')) {
        $new_limit = (float) $_GET['update_limit'];
        $user_id = (int) $_GET['user_id'];

        update_user_meta($user_id, 'limite_mensual', $new_limit);

        // Redirigir para limpiar la URL
        wp_redirect(remove_query_arg(['update_limit', 'user_id']));
        exit;
    }
});