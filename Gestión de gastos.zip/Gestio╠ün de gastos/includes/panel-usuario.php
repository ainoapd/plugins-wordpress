<?php
add_shortcode('panel_usuario', function() {
    if (!is_user_logged_in()) return '<p>Debes iniciar sesión para ver tu panel.</p>';

    $user_id = get_current_user_id();
    $limite = (float) get_user_meta($user_id, 'limite_mensual', true);
    $gasto = (float) get_user_meta($user_id, 'gasto_mensual', true);
    $saldo = $limite - $gasto;

    ob_start(); ?>
    <div class="gg-card">
        <h3>Tu Panel</h3>
        <p><strong>Límite mensual:</strong> <?php echo number_format($limite, 2); ?> €</p>
        <p><strong>Gasto actual:</strong> <?php echo number_format($gasto, 2); ?> €</p>
        <p><strong>Saldo restante:</strong> <?php echo number_format($saldo, 2); ?> €</p>
    </div>
    <?php return ob_get_clean();
});
?>
