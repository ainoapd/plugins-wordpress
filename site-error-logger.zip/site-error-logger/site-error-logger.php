<?php
/**
 * Plugin Name: Site Error Logger
 * Description: Muestra un log de errores recientes del sitio y permite activar WP_DEBUG desde una pestaña de configuración.
 * Version: 1.2
 * Author: Ainoa Parra Duque
 */

if (!defined('ABSPATH')) exit;

// Menú principal
add_action('admin_menu', 'site_error_logger_menu');
function site_error_logger_menu() {
    add_menu_page('Errores del sitio', 'Errores del sitio', 'manage_options', 'site-error-logger', 'site_error_logger_page', 'dashicons-warning', 80);
    add_submenu_page('site-error-logger', 'Configuración de depuración', 'Configuración', 'manage_options', 'site-error-logger-settings', 'site_error_logger_settings_page');
}

// Página del log de errores
function site_error_logger_page() {
    $log_file = WP_CONTENT_DIR . '/debug.log';

    echo '<div class="wrap"><h1>Errores recientes del sitio</h1>';

    if (file_exists($log_file)) {
        $log = file_get_contents($log_file);
        $lines = explode("\n", $log);
        $lines = array_slice($lines, -50);

        echo '<pre style="background: #fff; padding: 15px; border: 1px solid #ccd0d4; max-height: 500px; overflow: auto;">';
        foreach ($lines as $line) {
            echo esc_html($line) . "\n";
        }
        echo '</pre>';
    } else {
        echo '<p>No se encontró el archivo debug.log. Asegúrate de que WP_DEBUG esté activado y que existan errores registrados.</p>';
    }

    echo '</div>';
}

// Página de configuración
function site_error_logger_settings_page() {
    echo '<div class="wrap"><h1>Configuración de depuración</h1>';

    if (isset($_POST['enable_debug'])) {
        $config_path = ABSPATH . 'wp-config.php';
        $config_content = file_get_contents($config_path);

        if (strpos($config_content, "define('WP_DEBUG', true);") === false) {
            $config_content = preg_replace("/(\/\/\s*Enable WP_DEBUG|\?>)/", "define('WP_DEBUG', true);\ndefine('WP_DEBUG_LOG', true);\n$1", $config_content, 1);
            file_put_contents($config_path, $config_content);
            echo '<div class="updated"><p>WP_DEBUG y WP_DEBUG_LOG activados.</p></div>';
        } else {
            echo '<div class="notice notice-warning"><p>WP_DEBUG ya estaba activado.</p></div>';
        }
    }

    echo '<form method="post">';
    echo '<p><input type="submit" name="enable_debug" class="button button-primary" value="Activar WP_DEBUG y WP_DEBUG_LOG"></p>';
    echo '</form>';
    echo '</div>';
}
