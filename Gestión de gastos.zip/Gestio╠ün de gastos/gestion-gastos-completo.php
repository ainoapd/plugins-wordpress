<?php
/*
Plugin Name: Gestión de Gastos Completo
Description: Plugin para gestionar límites de gasto mensuales con panel de usuario y gestor.
Version: 1.0
Author: Ainoa Parra Duque
*/

defined('ABSPATH') || exit;

// Estilos
function gg_enqueue_styles() {
    wp_enqueue_style('gg-style', plugin_dir_url(__FILE__) . 'assets/style.css');
}
add_action('wp_enqueue_scripts', 'gg_enqueue_styles');

// Includes
include_once plugin_dir_path(__FILE__) . 'includes/panel-usuario.php';
include_once plugin_dir_path(__FILE__) . 'includes/panel-gestor.php';
include_once plugin_dir_path(__FILE__) . 'includes/logic.php';

function gg_enqueue_assets() {
    wp_enqueue_style('gg-style', plugin_dir_url(__FILE__) . 'assets/style.css');
    wp_enqueue_script('gg-script', plugin_dir_url(__FILE__) . 'assets/script.js', [], false, true);
}
add_action('wp_enqueue_scripts', 'gg_enqueue_assets');
?>